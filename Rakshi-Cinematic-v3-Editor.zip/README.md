# Rakshi Cinematic editor v3

This is source code and a GitHub Actions workflow, not a prebuilt APK.

## Install from your existing GitHub repository on mobile

1. Download this archive and extract it with Samsung My Files.
2. Open the visible `build.yml` in the extracted folder with a text editor and copy all its contents.
3. In rakshi2603/Rakshi-cinematic-new, open `.github/workflows/build.yml`, tap Edit, replace the contents, then commit to main. Keep your existing root `rakshi-cinematic-app (1).zip` in place. The workflow contains the complete new Kotlin source; no other upload is needed.
4. Open Actions and tap the latest run title. When it finishes successfully, open its run summary and scroll to Artifacts. Download `RakshiCinematicAI-Debug-APK`, extract its ZIP, then install the `.apk` inside. You must be signed in to GitHub.
5. If it fails, share the first actual error from the Build Debug APK step. A green run confirms compilation, not phone export compatibility.

## Features implemented

- Several video inputs using the Android document picker, with persistent read grants.
- Bundled ML Kit frame labels for general scenes, with AUTO, CAR and BIKE ranking preferences. Labels and exposure/detail/frame differences rank fixed four-second candidates; this is not story understanding, action detection or optical flow. Long videos are sampled, up to roughly 1200 frames total.
- Suggested color look based on observed scene labels, plus manual cinematic/warm/cool/vivid/monochrome/neutral looks.
- RGB grading, brightness, contrast and saturation actually applied to exported frames using Media3.
- Landscape, portrait or square 1080p framing, fit or centre crop, rotation and mirror.
- Constant 0.5x/1x/1.5x/2x speed, with pitch-preserving source audio processing. Slower speed is frame retiming, not AI frame interpolation.
- Optional full-footage editing instead of highlight selection; remove clips from either timeline.
- Select your own background music, or use original procedural calm/cinematic/energetic accompaniment. Music loops to fit. Original sound/music gain controls use conservative combined gain normalization; no beat-synced cutting or ducking.
- Save to Movies/RakshiCinematic, play and share through Android.
- Optional Gemini Nano middle-frame description for the first video through ML Kit/AICore. Setup may download model assets; footage is processed on device. Runtime availability is checked. Galaxy S25 Ultra is listed for feature-specific ML Kit GenAI APIs, but support depends on its software/model configuration. Basic labeling and editing do not need Nano.

## Scope and limitations

This is a substantial editor prototype, not a universal automatic professional editor. Samsung Gallery's entire Galaxy AI toolset is not integrated. Nano descriptions are displayed separately; they do not yet drive edit decisions. The scene model cannot identify every event, person or arbitrary video type. Looks are predefined adjustments and do not implement shot-to-shot exposure matching, LUT import or HDR color management. No captions, text overlays, transitions, object removal, stabilization, multi-track manual timeline or generative video/music is claimed.

Keep the app open and screen on during analysis/export. Work is scoped to the Compose screen and cancels when it is removed; timelines/settings aren't restored after activity/process recreation. Extremely long clips can take substantial time and storage. No live effects preview is included; review the exported video. Your selected audio should be compatible with Android's decoders and permitted for your intended use. Gallery saving needs Android 10+; this target phone qualifies.

## Verification and build

Locally checked: YAML parsing, syntax of every workflow shell step, dependency patch idempotence on the original base project, and exact match between workflow-generated Kotlin and packaged source. The Android SDK, Gradle and Kotlin compiler are unavailable in this environment, so an APK build and real-device export test have not been run. This does not supersede your prior successful build of the old version.

The full Android scaffold is included for Android Studio. Alternatively the included workflow uses JDK 17, Gradle 8.11.1, AGP 8.8.0, Kotlin 2.1.0 and Media3 1.5.1, matching the repository base. It adds bundled image-labeling 17.0.9 and image-description 1.0.0-beta1. Version code is 3.

## Implementation record

Derived from the original repository base ZIP and its main workflow fetched for this upgrade. AndroidX Media3 APIs were checked against tag 1.5.1. ML Kit GenAI API signatures, dependency and S25 Ultra feature support were checked against Google's official documentation. The original base scaffold is included unchanged as rakshi-cinematic-app.zip for the workflow. Replacing only the workflow is sufficient in the existing repository.

References:
- https://developers.google.com/ml-kit/genai
- https://developers.google.com/ml-kit/genai/image-description/android
- https://developers.google.com/android/reference/com/google/mlkit/genai/imagedescription/ImageDescriber
- https://github.com/androidx/media/tree/1.5.1
