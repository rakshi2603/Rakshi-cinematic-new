package com.rakshi.cinematic

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.media3.common.Effect
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Effects
import com.google.mlkit.genai.imagedescription.ImageDescription
import com.google.mlkit.genai.imagedescription.ImageDescriberOptions
import com.google.mlkit.genai.imagedescription.ImageDescriptionRequest
import com.google.mlkit.genai.common.FeatureStatus

import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.util.concurrent.TimeUnit
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper

import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import androidx.lifecycle.lifecycleScope

import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

import java.io.File

data class HighlightSegment(
    val sourceUri: Uri,
    val startMs: Long,
    val endMs: Long
) {
    val durationMs: Long
        get() = endMs - startMs
}

data class SceneAnalysis(val cuts: List<HighlightSegment>, val summary: String, val look: String)

object VideoAnalysisEngine {
    data class Candidate(val sourceUri: Uri, val sourceIndex: Int, val startMs: Long, val endMs: Long, val score: Double)

    suspend fun selectClips(
        context: Context,
        uris: List<Uri>,
        preset: String,
        targetMs: Long,
        onProgress: suspend (Int) -> Unit
    ): SceneAnalysis = withContext(Dispatchers.IO) {
        require(uris.isNotEmpty()) { "Select at least one video." }
        require(targetMs > 0L)
        val candidates = mutableListOf<Candidate>()
        val observations = mutableMapOf<String, Double>()
        var readableFrames = 0
        var totalDurationMs = 0L
        val labeler = ImageLabeling.getClient(
            ImageLabelerOptions.Builder().setConfidenceThreshold(0.35f).build()
        )
        try {
          for ((sourceIndex, uri) in uris.withIndex()) {
            currentCoroutineContext().ensureActive()
            val retriever = MediaMetadataRetriever()
            try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L
            require(durationMs > 0L) { "Cannot read video "+(sourceIndex+1)+". Remove it and retry." }
            totalDurationMs += durationMs
            val windowMs = 4_000L
            val windowCount = (durationMs - 1L) / windowMs + 1L
            val candidateCount = minOf(windowCount, (1200L / uris.size).coerceAtLeast(1L)).toInt()
            var previousPixels: DoubleArray? = null
            for (index in 0 until candidateCount) {
                currentCoroutineContext().ensureActive()
                val windowIndex = if (candidateCount > 1) {
                    index.toLong() * (windowCount - 1L) / (candidateCount - 1L)
                } else 0L
                val start = windowIndex * windowMs
                val end = minOf(start + windowMs, durationMs)
                val atMs = start + (end - start) / 2L
                val frame = if (Build.VERSION.SDK_INT >= 27) {
                    retriever.getScaledFrameAtTime(
                        atMs * 1000L,
                        MediaMetadataRetriever.OPTION_CLOSEST,
                        320, 180
                    )
                } else {
                    retriever.getFrameAtTime(
                        atMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST
                    )
                }
                var score = -1.0
                if (frame != null) {
                    var tiny: Bitmap? = null
                    try {
                        val labels = Tasks.await(
                            labeler.process(InputImage.fromBitmap(frame, 0)),
                            20L, TimeUnit.SECONDS
                        )
                        readableFrames++
                        labels.forEach { label ->
                            observations[label.text] = (observations[label.text] ?: 0.0) + label.confidence
                        }
                        tiny = Bitmap.createScaledBitmap(frame, 32, 18, true)
                        val pixels = IntArray(32 * 18)
                        tiny.getPixels(pixels, 0, 32, 0, 0, 32, 18)
                        val luminance = DoubleArray(pixels.size) { p ->
                            val color = pixels[p]
                            (0.2126 * android.graphics.Color.red(color) +
                                0.7152 * android.graphics.Color.green(color) +
                                0.0722 * android.graphics.Color.blue(color)) / 255.0
                        }
                        val usableExposure = luminance.count {
                            it in 0.06..0.94
                        }.toDouble() / luminance.size
                        var gradient = 0.0
                        var edges = 0
                        for (y in 0 until 18) for (x in 0 until 31) {
                            val p = y * 32 + x
                            gradient += kotlin.math.abs(luminance[p] - luminance[p + 1])
                            edges++
                        }
                        val detail = (gradient / edges * 6.0).coerceIn(0.0, 1.0)
                        val previous = previousPixels
                        val change = if (previous == null) 0.0 else {
                            luminance.indices.sumOf {
                                kotlin.math.abs(luminance[it] - previous[it])
                            } / luminance.size
                        }
                        previousPixels = luminance
                        val wanted = if (preset == "BIKE") {
                            setOf("motorcycle", "motorcycling", "helmet", "vehicle",
                                "road", "mountain", "landscape", "sky", "tree")
                        } else {
                            setOf("car", "vehicle", "road", "wheel", "landscape",
                                "mountain", "sky", "building", "tree")
                        }
                        val semantic = if (preset == "AUTO") labels.maxOfOrNull { it.confidence.toDouble() } ?: 0.0 else labels.filter { label ->
                            wanted.any { keyword ->
                                label.text.lowercase(java.util.Locale.ROOT)
                                    .contains(keyword)
                            }
                        }.maxOfOrNull { it.confidence.toDouble() } ?: 0.0
                        // Neural scene labels + explicit ranking heuristics.
                        // Frame differences are not optical flow or stabilization.
                        val changePreference = if (change <= 0.20) {
                            (change / 0.20).coerceIn(0.0, 1.0)
                        } else {
                            (1.0 - (change - 0.20) / 0.40).coerceIn(0.0, 1.0)
                        }
                        score = (0.50 * semantic + 0.25 * usableExposure +
                            0.15 * detail + 0.10 * changePreference) * usableExposure
                    } finally {
                        if (tiny != null && tiny !== frame) tiny.recycle()
                        frame.recycle()
                    }
                }
                candidates.add(Candidate(uri, sourceIndex, start, end, score))
                onProgress(((sourceIndex + (index + 1).toDouble() / candidateCount) * 100 / uris.size).toInt())
            }
            } finally {
                retriever.release()
            }
          }
            require(readableFrames > 0) {
                "No frames could be analysed. Try a different video."
            }
            val desired = minOf(targetMs, totalDurationMs)
            var remaining = desired
            val chosen = mutableListOf<HighlightSegment>()
            // Candidates partition the source, so selected clips cannot overlap.
            for (candidate in candidates.filter { it.score >= 0.0 }
                .sortedByDescending { it.score }) {
                if (remaining <= 0L) break
                val length = minOf(candidate.endMs - candidate.startMs, remaining)
                chosen.add(HighlightSegment(candidate.sourceUri, candidate.startMs,
                    candidate.startMs + length))
                remaining -= length
            }
            require(chosen.isNotEmpty()) { "No valid highlights found." }
            val labels = observations.entries.sortedByDescending { it.value }.take(6).map { it.key }
            val sceneText = labels.joinToString(", ")
            val scene = sceneText.lowercase(java.util.Locale.ROOT)
            val look = when {
                listOf("food", "flower", "plant", "tree", "landscape", "mountain").any { scene.contains(it) } -> "VIVID"
                listOf("person", "face", "baby", "wedding").any { scene.contains(it) } -> "WARM"
                listOf("snow", "water", "ocean").any { scene.contains(it) } -> "COOL"
                else -> "CINEMATIC"
            }
            SceneAnalysis(chosen.sortedWith(compareBy<HighlightSegment> { uris.indexOf(it.sourceUri) }.thenBy { it.startMs }),
                "Observed scene labels: ${sceneText.ifEmpty { "unclassified" }}. Look suggestions are heuristic.", look)
        } finally {
            labeler.close()
        }
    }
}

object GalleryExport {
    fun save(context: Context, file: File): Uri {
        require(Build.VERSION.SDK_INT >= 29) {
            "Gallery export requires Android 10 or newer."
        }
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/RakshiCinematic")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values
        ) ?: error("Could not create Gallery video.")
        try {
            resolver.openOutputStream(uri)?.use { output ->
                file.inputStream().use { input -> input.copyTo(output) }
            } ?: error("Could not write Gallery video.")
            val published = ContentValues().apply {
                put(MediaStore.Video.Media.IS_PENDING, 0)
            }
            check(resolver.update(uri, published, null, null) > 0) {
                "Could not publish Gallery video."
            }
            return uri
        } catch (error: Exception) {
            resolver.delete(uri, null, null)
            throw error
        }
    }
}


class SimpleRenderEngine(
    private val context: Context
) {
    sealed interface RenderState {
        data class Progress(
            val percentage: Int
        ) : RenderState

        data class Completed(
            val file: File
        ) : RenderState

        data class Error(
            val message: String
        ) : RenderState
    }

    fun exportReel(
        cuts: List<HighlightSegment>,
        outputFile: File,
        settings: EditSettings,
        suggestedLook: String,
        musicUri: Uri?
    ): Flow<RenderState> = callbackFlow {
        val handler = Handler(Looper.getMainLooper())
        var transformer: Transformer? = null
        var progressTask: Runnable? = null
        var finished = false

        try {
            require(cuts.isNotEmpty()) {
                "No clips selected."
            }

            cuts.forEach { cut ->
                require(
                    cut.startMs >= 0L &&
                    cut.endMs > cut.startMs
                ) {
                    "Invalid clip boundaries."
                }
            }

            outputFile.parentFile?.let { directory ->
                check(
                    directory.isDirectory ||
                    directory.mkdirs()
                ) {
                    "Could not create output directory."
                }
            }

            if (outputFile.exists()) {
                check(outputFile.delete()) {
                    "Could not replace output file."
                }
            }

            val items = cuts.map { cut ->
                val clipping =
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(cut.startMs)
                        .setEndPositionMs(cut.endMs)
                        .build()

                val mediaItem = MediaItem.Builder()
                    .setUri(cut.sourceUri)
                    .setClippingConfiguration(clipping)
                    .build()

                EditedMediaItem.Builder(mediaItem).setEffects(EditEffects.forClip(settings, suggestedLook, musicUri != null)).build()
            }

            val sequence = EditedMediaItemSequence(items)
            val sequences = mutableListOf(sequence)
            if (musicUri != null) {
                val normalizer = maxOf(1f, settings.sourceVolume + settings.musicVolume)
                val music = EditedMediaItem.Builder(MediaItem.fromUri(musicUri))
                    .setRemoveVideo(true)
                    .setEffects(Effects(listOf(EditEffects.gain(settings.musicVolume / normalizer)), emptyList()))
                    .build()
                sequences.add(EditedMediaItemSequence.Builder(listOf(music)).setIsLooping(true).build())
            }
            val composition = Composition.Builder(sequences).build()

            val exporter = Transformer.Builder(context)
                .addListener(
                    object : Transformer.Listener {
                        override fun onCompleted(
                            composition: Composition,
                            exportResult: ExportResult
                        ) {
                            finished = true
                            trySend(RenderState.Progress(100))
                            trySend(
                                RenderState.Completed(outputFile)
                            )
                            close()
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException
                        ) {
                            finished = true
                            trySend(
                                RenderState.Error(
                                    exportException.message
                                        ?: "Export failed."
                                )
                            )
                            close()
                        }
                    }
                )
                .build()

            transformer = exporter
            val holder = ProgressHolder()

            val poller = object : Runnable {
                override fun run() {
                    if (finished || isClosedForSend) {
                        return
                    }

                    try {
                        val state =
                            exporter.getProgress(holder)

                        if (
                            state ==
                            Transformer.PROGRESS_STATE_AVAILABLE
                        ) {
                            trySend(
                                RenderState.Progress(
                                    holder.progress
                                        .coerceIn(0, 100)
                                )
                            )
                        }

                        handler.postDelayed(this, 300L)
                    } catch (error: Exception) {
                        finished = true
                        trySend(
                            RenderState.Error(
                                error.message
                                    ?: "Progress check failed."
                            )
                        )
                        close()
                    }
                }
            }

            progressTask = poller
            exporter.start(
                composition,
                outputFile.absolutePath
            )
            handler.postDelayed(poller, 200L)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            finished = true
            trySend(
                RenderState.Error(
                    error.message
                        ?: "Could not initialize export."
                )
            )
            close()
        }

        awaitClose {
            finished = true

            progressTask?.let {
                handler.removeCallbacks(it)
            }

            val activeTransformer = transformer
            if (activeTransformer != null) {
                if (
                    Looper.myLooper() ==
                    Looper.getMainLooper()
                ) {
                    activeTransformer.cancel()
                } else {
                    handler.post {
                        activeTransformer.cancel()
                    }
                }
            }
        }
    }.flowOn(Dispatchers.Main.immediate)
}


data class EditSettings(
    val look: String = "AUTO",
    val aspect: String = "16:9",
    val crop: Boolean = false,
    val speed: Float = 1f,
    val exposure: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val rotation: Float = 0f,
    val mirror: Boolean = false,
    val sourceVolume: Float = 1f,
    val musicVolume: Float = 0.45f,
    val musicMode: String = "NONE",
    val musicUri: Uri? = null
)

object EditEffects {
    fun gain(value: Float): ChannelMixingAudioProcessor =
        ChannelMixingAudioProcessor().apply {
            for (channels in 1..8) {
                putChannelMixingMatrix(
                    ChannelMixingMatrix.create(channels, channels)
                        .scaleBy(value.coerceIn(0f, 1f))
                )
            }
        }

    fun forClip(settings: EditSettings, suggestedLook: String, withMusic: Boolean): Effects {
        val audio = mutableListOf<AudioProcessor>()
        val normalizer = if (withMusic) {
            maxOf(1f, settings.sourceVolume + settings.musicVolume)
        } else 1f
        audio.add(gain(settings.sourceVolume / normalizer))
        if (settings.speed != 1f) {
            audio.add(SonicAudioProcessor().apply {
                setSpeed(settings.speed)
                setPitch(1f)
            })
        }
        val video = mutableListOf<Effect>()
        val look = if (settings.look == "AUTO") suggestedLook else settings.look
        var red = 1f
        var green = 1f
        var blue = 1f
        var contrast = 0f
        var saturation = 0f
        when (look) {
            "CINEMATIC" -> { red = 1.04f; green = 1.01f; blue = 0.95f; contrast = 0.10f; saturation = -8f }
            "WARM" -> { red = 1.08f; blue = 0.94f; saturation = 4f }
            "COOL" -> { red = 0.96f; blue = 1.08f; contrast = 0.04f }
            "VIVID" -> { saturation = 16f; contrast = 0.08f }
            "MONO" -> { saturation = -100f; contrast = 0.10f }
        }
        video.add(RgbAdjustment.Builder().setRedScale(red)
            .setGreenScale(green).setBlueScale(blue).build())
        video.add(Brightness(settings.exposure.coerceIn(-1f, 1f)))
        video.add(Contrast((contrast + settings.contrast).coerceIn(-1f, 1f)))
        video.add(HslAdjustment.Builder().adjustSaturation(
            (saturation + settings.saturation).coerceIn(-100f, 100f)
        ).build())
        if (settings.rotation != 0f || settings.mirror) {
            video.add(ScaleAndRotateTransformation.Builder()
                .setRotationDegrees(settings.rotation)
                .setScale(if (settings.mirror) -1f else 1f, 1f).build())
        }
        val dimensions = when (settings.aspect) {
            "9:16" -> 1080 to 1920
            "1:1" -> 1080 to 1080
            else -> 1920 to 1080
        }
        video.add(Presentation.createForWidthAndHeight(
            dimensions.first, dimensions.second,
            if (settings.crop) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
            else Presentation.LAYOUT_SCALE_TO_FIT
        ))
        if (settings.speed != 1f) video.add(SpeedChangeEffect(settings.speed))
        return Effects(audio, video)
    }
}

object LocalMusic {
    // Original procedural accompaniment; no external recordings or cloud calls.
    fun create(context: Context, mood: String, durationMs: Long): Uri {
        val file = File(context.cacheDir, "rakshi-music.wav")
        val sampleRate = 44_100
        val seconds = (durationMs / 1000.0).coerceIn(1.0, 180.0)
        val count = (seconds * sampleRate).toInt()
        val bpm = when (mood) { "ENERGETIC" -> 120.0; "CALM" -> 75.0; else -> 90.0 }
        val beatSeconds = 60.0 / bpm
        val chords = arrayOf(
            doubleArrayOf(220.0, 261.63, 329.63),
            doubleArrayOf(174.61, 220.0, 261.63),
            doubleArrayOf(130.81, 164.81, 196.0),
            doubleArrayOf(196.0, 246.94, 293.66)
        )
        val random = java.util.Random(2603)
        java.io.BufferedOutputStream(file.outputStream()).use { output ->
            fun intLE(value: Int) {
                repeat(4) { output.write((value ushr (it * 8)) and 255) }
            }
            fun shortLE(value: Int) {
                output.write(value and 255)
                output.write((value ushr 8) and 255)
            }
            output.write("RIFF".toByteArray(Charsets.US_ASCII)); intLE(36 + count * 2)
            output.write("WAVEfmt ".toByteArray(Charsets.US_ASCII)); intLE(16)
            shortLE(1); shortLE(1); intLE(sampleRate); intLE(sampleRate * 2)
            shortLE(2); shortLE(16)
            output.write("data".toByteArray(Charsets.US_ASCII)); intLE(count * 2)
            for (sample in 0 until count) {
                val time = sample.toDouble() / sampleRate
                val chord = chords[(time / (beatSeconds * 4)).toInt() % chords.size]
                val beatPhase = time % beatSeconds
                val halfBeat = time % (beatSeconds / 2)
                var signal = chord.sumOf { frequency ->
                    kotlin.math.sin(2 * Math.PI * frequency * time) *
                        (0.035 + 0.035 * kotlin.math.exp(-beatPhase * 3))
                }
                if (mood != "CALM") {
                    signal += 0.13 * kotlin.math.sin(2 * Math.PI *
                        (50 * beatPhase + 5 * (1 - kotlin.math.exp(-beatPhase * 20)))) *
                        kotlin.math.exp(-beatPhase * 18)
                    signal += (random.nextDouble() * 2 - 1) * 0.035 *
                        kotlin.math.exp(-halfBeat * 65)
                }
                val fade = minOf(1.0, time / 1.2, (seconds - time) / 1.5).coerceAtLeast(0.0)
                val pcm = (signal * fade * 32767).toInt().coerceIn(-32768, 32767)
                shortLE(pcm)
            }
        }
        return Uri.fromFile(file)
    }
}

suspend fun <T> com.google.common.util.concurrent.ListenableFuture<T>.awaitNano(): T =
    kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation { cancel(true) }
        addListener({
            try { continuation.resumeWith(Result.success(get())) }
            catch (error: Exception) { continuation.resumeWith(Result.failure(error.cause ?: error)) }
        }, java.util.concurrent.Executor { it.run() })
    }

object NanoScenes {
    suspend fun prepare(context: Context): String = withContext(Dispatchers.IO) {
        val client = ImageDescription.getClient(ImageDescriberOptions.builder(context).build())
        try {
            when (client.checkFeatureStatus().awaitNano()) {
                FeatureStatus.UNAVAILABLE -> "Nano image descriptions unavailable on this phone configuration."
                FeatureStatus.AVAILABLE -> "Nano is ready."
                else -> {
                    // Explicit setup button allows model download; no video is uploaded.
                    client.prepareInferenceEngine().awaitNano()
                    "Nano is ready."
                }
            }
        } finally { client.close() }
    }

    suspend fun describe(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        val client = ImageDescription.getClient(ImageDescriberOptions.builder(context).build())
        val retriever = MediaMetadataRetriever()
        var bitmap: Bitmap? = null
        try {
            require(client.checkFeatureStatus().awaitNano() == FeatureStatus.AVAILABLE) {
                "Set up Nano first. Bundled scene analysis still works without it."
            }
            retriever.setDataSource(context, uri)
            val duration = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L
            bitmap = retriever.getScaledFrameAtTime(
                duration * 500L, MediaMetadataRetriever.OPTION_CLOSEST, 512, 288
            )
            val frame = bitmap ?: error("Could not decode scene frame.")
            client.runInference(ImageDescriptionRequest.builder(frame).build())
                .awaitNano().description
        } finally {
            bitmap?.recycle()
            retriever.release()
            client.close()
        }
    }
}

@Composable
fun ChoiceRow(title: String, values: List<String>, selected: String, enabled: Boolean, choose: (String) -> Unit) {
    Text(title)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        values.forEach { value -> FilterChip(selected == value, { choose(value) }, { Text(value) }, enabled = enabled) }
    }
}

@Composable
fun EditSlider(title: String, value: Float, range: ClosedFloatingPointRange<Float>, enabled: Boolean, change: (Float) -> Unit) {
    Text("$title: ${"%.2f".format(value)}")
    Slider(value = value, onValueChange = change, valueRange = range, enabled = enabled)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val engine = SimpleRenderEngine(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFFF5722))) {
                var sources by remember { mutableStateOf(emptyList<Uri>()) }
                var cuts by remember { mutableStateOf(emptyList<HighlightSegment>()) }
                var settings by remember { mutableStateOf(EditSettings()) }
                var seconds by remember { mutableIntStateOf(60) }
                var preset by remember { mutableStateOf("AUTO") }
                var summary by remember { mutableStateOf("Select several videos, then analyse.") }
                var look by remember { mutableStateOf("CINEMATIC") }
                var busy by remember { mutableStateOf(false) }
                var status by remember { mutableStateOf("Ready") }
                var progress by remember { mutableIntStateOf(0) }
                var output by remember { mutableStateOf<File?>(null) }
                var gallery by remember { mutableStateOf<Uri?>(null) }
                val scope = rememberCoroutineScope()
                val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selected ->
                    if (selected.isNotEmpty()) {
                        sources = selected.distinct(); cuts = emptyList(); output = null; gallery = null
                        sources.forEach { uri ->
                            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                            catch (_: SecurityException) { }
                        }
                        summary = "${sources.size} videos selected."
                    }
                }
                val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) {
                        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                        catch (_: SecurityException) { }
                        settings = settings.copy(musicMode = "FILE", musicUri = uri)
                    }
                }
                Surface(Modifier.fillMaxSize()) {
                    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 32.dp)) {
                        item {
                            Text("RAKSHI CINEMATIC", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Text("Scene analysis • color • framing • music", color = MaterialTheme.colorScheme.primary)
                            Text(status)
                            if (busy) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
                            Button({ picker.launch(arrayOf("video/*")) }, enabled = !busy) { Text("Select videos (${sources.size})") }
                            ChoiceRow("Scene preference", listOf("AUTO", "CAR", "BIKE"), preset, !busy) { preset = it; cuts = emptyList() }
                            ChoiceRow("Reel length", listOf("15", "30", "60"), seconds.toString(), !busy) { seconds = it.toInt(); cuts = emptyList() }
                            Button(onClick = {
                                busy = true; progress = 0; output = null; gallery = null
                                val selected = sources.toList()
                                val request = settings
                                scope.launch {
                                    try {
                                        val result = VideoAnalysisEngine.selectClips(applicationContext, selected, preset,
                                            (seconds * 1000L * request.speed).toLong()) { p ->
                                            withContext(Dispatchers.Main) { progress = p; status = "Analysing frames: $p%" }
                                        }
                                        cuts = result.cuts; look = result.look; summary = result.summary
                                        status = "Timeline ready. Suggested look: $look"
                                    } catch (e: CancellationException) { throw e }
                                    catch (e: Exception) { status = "Analysis failed: ${e.message}" }
                                    finally { busy = false }
                                }
                            }, enabled = sources.isNotEmpty() && !busy) { Text("Analyse & select highlights") }
                            OutlinedButton(onClick = {
                                busy = true; output = null; gallery = null
                                val selected = sources.toList()
                                scope.launch {
                                    try {
                                        cuts = withContext(Dispatchers.IO) {
                                            selected.map { uri ->
                                                val retriever = MediaMetadataRetriever()
                                                try {
                                                    retriever.setDataSource(applicationContext, uri)
                                                    val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                                                    require(duration > 0L) { "Cannot read a selected video." }
                                                    HighlightSegment(uri, 0L, duration)
                                                } finally { retriever.release() }
                                            }
                                        }
                                        status = "Full videos ready for editing."
                                    } catch (e: CancellationException) { throw e }
                                    catch (e: Exception) { status = "Read failed: ${e.message}" }
                                    finally { busy = false }
                                }
                            }, enabled = sources.isNotEmpty() && !busy) { Text("Use full videos without highlight cuts") }
                            Text(summary)
                            Text("Optional Nano: describes a middle frame, not the whole video.", fontSize = 12.sp)
                            Button(onClick = {
                                busy = true; status = "Preparing Nano; model download may be needed..."
                                scope.launch {
                                    try { status = NanoScenes.prepare(applicationContext) }
                                    catch (e: CancellationException) { throw e }
                                    catch (e: Exception) { status = "Nano unavailable: ${e.message}. Basic analysis still works." }
                                    finally { busy = false }
                                }
                            }, enabled = !busy) { Text("Set up on-device Nano (may download)") }
                            OutlinedButton(onClick = {
                                busy = true
                                scope.launch {
                                    try { status = NanoScenes.describe(applicationContext, sources.first()) }
                                    catch (e: CancellationException) { throw e }
                                    catch (e: Exception) { status = "Description unavailable: ${e.message}" }
                                    finally { busy = false }
                                }
                            }, enabled = sources.isNotEmpty() && !busy) { Text("Describe first video's scene") }
                        }
                        item {
                            ChoiceRow("Color look", listOf("AUTO", "NONE", "CINEMATIC", "WARM", "COOL", "VIVID", "MONO"), settings.look, !busy) { settings = settings.copy(look = it) }
                            EditSlider("Brightness", settings.exposure, -0.5f..0.5f, !busy) { settings = settings.copy(exposure = it) }
                            EditSlider("Contrast", settings.contrast, -0.5f..0.5f, !busy) { settings = settings.copy(contrast = it) }
                            EditSlider("Saturation", settings.saturation, -50f..50f, !busy) { settings = settings.copy(saturation = it) }
                            ChoiceRow("Frame", listOf("16:9", "9:16", "1:1"), settings.aspect, !busy) { settings = settings.copy(aspect = it) }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(settings.crop, { settings = settings.copy(crop = it) }, enabled = !busy)
                                Text(if (settings.crop) "Centre crop" else "Fit with borders")
                            }
                            ChoiceRow("Speed (re-analyse after change)", listOf("0.5", "1.0", "1.5", "2.0"), settings.speed.toString(), !busy) { settings = settings.copy(speed = it.toFloat()); cuts = emptyList() }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton({ settings = settings.copy(rotation = (settings.rotation + 90f) % 360f) }, enabled = !busy) { Text("Rotate ${settings.rotation.toInt()}°") }
                                OutlinedButton({ settings = settings.copy(mirror = !settings.mirror) }, enabled = !busy) { Text(if (settings.mirror) "Mirrored" else "Mirror") }
                            }
                            ChoiceRow("Background music", listOf("NONE", "CALM", "CINEMATIC", "ENERGETIC", "FILE"), settings.musicMode, !busy) {
                                if (it == "FILE") musicPicker.launch(arrayOf("audio/*")) else settings = settings.copy(musicMode = it)
                            }
                            Text(if (settings.musicMode == "FILE") "${if (settings.musicUri == null) "Choose an audio file" else "Selected audio will loop to fit"}" else "Built-in music is original procedural accompaniment.", fontSize = 12.sp)
                            EditSlider("Original sound", settings.sourceVolume, 0f..1f, !busy) { settings = settings.copy(sourceVolume = it) }
                            EditSlider("Music volume", settings.musicVolume, 0f..1f, !busy) { settings = settings.copy(musicVolume = it) }
                            Text("Timeline: ${cuts.size} clips • ${"%.1f".format(cuts.sumOf { it.durationMs } / (1000f * settings.speed))}s output")
                        }
                        itemsIndexed(cuts) { index, cut ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("Video ${sources.indexOf(cut.sourceUri) + 1}: ${cut.startMs / 1000f}–${cut.endMs / 1000f}s", Modifier.weight(1f))
                                TextButton({ cuts = cuts.filterIndexed { i, _ -> i != index } }, enabled = !busy) { Text("Remove") }
                            }
                        }
                        item {
                            Text("Effects appear in the exported video. Keep the app open during export.", fontSize = 12.sp)
                            Button(onClick = {
                                busy = true; progress = 0; output = null; gallery = null
                                val selected = cuts.toList(); val request = settings; val suggested = look
                                scope.launch {
                                    var destination: File? = null
                                    try {
                                        status = "Preparing music..."
                                        val music = when (request.musicMode) {
                                            "NONE" -> null
                                            "FILE" -> request.musicUri ?: error("Select a music file first.")
                                            else -> withContext(Dispatchers.IO) { LocalMusic.create(applicationContext, request.musicMode,
                                                (selected.sumOf { it.durationMs } / request.speed).toLong()) }
                                        }
                                        val file = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir,
                                            "RAKSHI_EDIT_${System.currentTimeMillis()}.mp4")
                                        destination = file
                                        status = "Rendering effects and audio..."
                                        engine.exportReel(selected, file, request, suggested, music).collect { state ->
                                            when (state) {
                                                is SimpleRenderEngine.RenderState.Progress -> progress = state.percentage
                                                is SimpleRenderEngine.RenderState.Completed -> { output = state.file; status = "Export complete. Save to Gallery." }
                                                is SimpleRenderEngine.RenderState.Error -> status = "Export failed: ${state.message}"
                                            }
                                        }
                                    } catch (e: CancellationException) { throw e }
                                    catch (e: Exception) { status = "Export failed: ${e.message}" }
                                    finally { if (output == null) destination?.delete(); busy = false }
                                }
                            }, enabled = cuts.isNotEmpty() && !busy, modifier = Modifier.fillMaxWidth()) { Text("Export edited reel") }
                            output?.let { file ->
                                OutlinedButton(onClick = {
                                    busy = true
                                    scope.launch {
                                        try { gallery = withContext(Dispatchers.IO) { GalleryExport.save(applicationContext, file) }; status = "Saved to Movies/RakshiCinematic" }
                                        catch (e: CancellationException) { throw e }
                                        catch (e: Exception) { status = "Save failed: ${e.message}" }
                                        finally { busy = false }
                                    }
                                }, enabled = !busy && gallery == null) { Text("Save to Gallery") }
                            }
                            gallery?.let { uri ->
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button({ try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (_: Exception) { status = "Open Samsung Gallery to play." } }) { Text("Play") }
                                    Button({ try {
                                        val intent = Intent(Intent.ACTION_SEND).apply { type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, uri); clipData = android.content.ClipData.newRawUri("Reel", uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                                        startActivity(Intent.createChooser(intent, "Share reel"))
                                    } catch (_: Exception) { status = "No sharing app available." } }) { Text("Share") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
