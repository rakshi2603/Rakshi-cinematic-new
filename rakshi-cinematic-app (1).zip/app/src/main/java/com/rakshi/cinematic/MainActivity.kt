package com.rakshi.cinematic
import android.os.Bundle
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var status by remember { mutableStateOf("Ready to Process") }
            var selectedUri by remember { mutableStateOf<Uri?>(null) }
            val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
                selectedUri = uri
                if (uri != null) status = "Footage Selected: Ready for 60s Reel"
            }
            Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0F1015)) {
                Column(modifier = Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("RAKSHI CINEMATIC AI", color = Color.White, fontSize = 22.sp)
                    Text("Auto Detect: Bike / Car / Cabin", color = Color(0xFFFF5722), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 24.dp))
                    Button(onClick = { picker.launch("video/*") }) { Text("Select GoPro Footage") }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(status, color = Color.LightGray, fontSize = 14.sp)
                }
            }
        }
    }
}
